If you want to use Disk icons, replace the content with Flavors-Magnifico-Disk
     